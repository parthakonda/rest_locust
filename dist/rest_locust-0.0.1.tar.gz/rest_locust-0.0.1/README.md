# rest_locust
Extended locust for quickly writing loadtests for locust
